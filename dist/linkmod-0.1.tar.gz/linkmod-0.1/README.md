# LinkMod

LinkMod is a Python tool that allows you to customize URLs by merging a user-provided string with a link.

## Usage

```bash
linkMod {original_link} {custom_string}
